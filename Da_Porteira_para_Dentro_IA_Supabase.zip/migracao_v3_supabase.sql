-- DA PORTEIRA PARA DENTRO IA — MIGRAÇÃO V3
-- Execute no SQL Editor de um projeto que já recebeu banco_de_dados_supabase.sql.
-- Esta migração preserva todos os dados existentes.

create table if not exists public.farm_app_states (
  farm_id uuid primary key references public.farms(id) on delete cascade,
  state jsonb not null default '{}'::jsonb,
  version bigint not null default 1,
  updated_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.has_farm_role(target_farm uuid, allowed_roles text[])
returns boolean language sql stable security definer set search_path=public as $$
  select exists (
    select 1 from public.farm_members fm
    where fm.farm_id=target_farm and fm.user_id=auth.uid()
      and fm.status='Ativo' and fm.role=any(allowed_roles)
  ) or exists (
    select 1 from public.farms f
    where f.id=target_farm and f.owner_id=auth.uid()
      and 'Proprietário'=any(allowed_roles)
  );
$$;

create or replace function public.create_farm_trial()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.subscriptions(
    farm_id,plan,amount,billing_cycle,provider,checkout_url,status,
    current_period_start,current_period_end
  ) values (
    new.id,'Teste gratuito — 30 dias',0,'trial','Kiwify',
    'https://pay.kiwify.com.br/kmJTFbU','trialing',new.trial_started_at,new.trial_ends_at
  ) on conflict (farm_id) do nothing;
  return new;
end;
$$;

drop trigger if exists create_farm_trial on public.farms;
create trigger create_farm_trial
after insert on public.farms
for each row execute function public.create_farm_trial();

insert into public.subscriptions(
  farm_id,plan,amount,billing_cycle,provider,checkout_url,status,
  current_period_start,current_period_end
)
select id,'Teste gratuito — 30 dias',0,'trial','Kiwify',
       'https://pay.kiwify.com.br/kmJTFbU','trialing',trial_started_at,trial_ends_at
from public.farms
on conflict (farm_id) do nothing;

drop policy if exists farm_insert_subscriptions on public.subscriptions;
drop policy if exists farm_update_subscriptions on public.subscriptions;
drop policy if exists farm_delete_subscriptions on public.subscriptions;
drop policy if exists farm_insert_subscription_events on public.subscription_events;
drop policy if exists farm_update_subscription_events on public.subscription_events;
drop policy if exists farm_delete_subscription_events on public.subscription_events;
drop policy if exists farm_update_audit_logs on public.audit_logs;
drop policy if exists farm_delete_audit_logs on public.audit_logs;

alter table public.farm_app_states enable row level security;
drop policy if exists farm_state_read on public.farm_app_states;
drop policy if exists farm_state_insert on public.farm_app_states;
drop policy if exists farm_state_update on public.farm_app_states;
create policy farm_state_read on public.farm_app_states for select
using (public.is_farm_member(farm_id));
create policy farm_state_insert on public.farm_app_states for insert
with check (public.has_farm_role(farm_id,array['Proprietário','Gestor','Encarregado','Financeiro']));
create policy farm_state_update on public.farm_app_states for update
using (public.has_farm_role(farm_id,array['Proprietário','Gestor','Encarregado','Financeiro']))
with check (public.has_farm_role(farm_id,array['Proprietário','Gestor','Encarregado','Financeiro']));

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values (
  'farm-files','farm-files',false,52428800,
  array['application/pdf','application/xml','text/xml','text/csv','application/octet-stream','image/jpeg','image/png','image/webp']
)
on conflict (id) do update set
  public=false,
  file_size_limit=excluded.file_size_limit,
  allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists farm_files_read on storage.objects;
drop policy if exists farm_files_insert on storage.objects;
drop policy if exists farm_files_update on storage.objects;
drop policy if exists farm_files_delete on storage.objects;
create policy farm_files_read on storage.objects for select to authenticated
using (bucket_id='farm-files' and public.is_farm_member(((storage.foldername(name))[1])::uuid));
create policy farm_files_insert on storage.objects for insert to authenticated
with check (bucket_id='farm-files' and public.has_farm_role(((storage.foldername(name))[1])::uuid,array['Proprietário','Gestor','Encarregado','Financeiro']));
create policy farm_files_update on storage.objects for update to authenticated
using (bucket_id='farm-files' and public.has_farm_role(((storage.foldername(name))[1])::uuid,array['Proprietário','Gestor','Encarregado','Financeiro']));
create policy farm_files_delete on storage.objects for delete to authenticated
using (bucket_id='farm-files' and public.has_farm_role(((storage.foldername(name))[1])::uuid,array['Proprietário','Gestor']));

create index if not exists idx_subscription_events_reference
on public.subscription_events(provider,event_type,created_at desc);

drop trigger if exists set_updated_at on public.farm_app_states;
create trigger set_updated_at before update on public.farm_app_states
for each row execute function public.set_updated_at();
