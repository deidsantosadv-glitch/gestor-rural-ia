# Ativação do login online

1. Crie ou abra o projeto no Supabase.
2. Banco novo: execute `banco_de_dados_supabase.sql` uma única vez. Banco que já recebeu a versão anterior: execute somente `migracao_v3_supabase.sql`.
3. Em **Project Settings > API**, copie somente:
   - Project URL;
   - chave pública `anon`/`publishable`.
4. Abra `config.js` e preencha `url` e `anonKey`.
5. Em **Authentication > URL Configuration**, cadastre o endereço publicado na Vercel em **Site URL** e **Redirect URLs**.
6. Na Vercel, cadastre as variáveis de `.env.example` em **Project Settings > Environment Variables**.
7. Publique todos os arquivos na Vercel, mantendo `index.html` e `config.js` na mesma pasta e a pasta `api` no projeto.

## Kiwify

1. Crie um segredo longo e aleatório e salve como `KIWIFY_WEBHOOK_SECRET` na Vercel.
2. Na Kiwify, em **Apps > Webhooks**, cadastre:
   `https://SEU-SITE.vercel.app/api/kiwify-webhook?token=SEU_SEGREDO`
3. Selecione o produto mensal de R$ 97,00 e os eventos de compra aprovada, renovação, atraso, cancelamento, reembolso e chargeback.
4. Use o botão de teste da Kiwify e confira o registro em `subscription_events`.
5. Quando a integração utilizada disponibilizar assinatura Ed25519, configure `KIWIFY_WEBHOOK_PUBLIC_KEY`; o endpoint valida também o timestamp contra reenvio indevido.

## Arquivos e sincronização

- O script SQL cria o bucket privado `farm-files`.
- Laudos, XML, extratos e documentos são gravados dentro da pasta da fazenda.
- Os módulos são sincronizados na tabela `farm_app_states` e continuam com cópia local para funcionamento resiliente.
- Proprietário e gestor podem convidar usuários. Cada convidado cria a própria senha pelo e-mail do Supabase.

## Segurança

- Nunca coloque a chave `service_role` no `index.html` ou no `config.js`.
- A `SUPABASE_SERVICE_ROLE_KEY` deve existir somente nas variáveis protegidas da Vercel.
- O cadastro, login e recuperação de senha usam o Supabase Auth.
- Sem a configuração pública, o sistema mantém o modo local apenas para demonstração.
- A confirmação dos pagamentos da Kiwify deve ser processada em endpoint de servidor e nunca diretamente no navegador.
