import crypto from 'node:crypto';

export const config = { api: { bodyParser: false } };

const SUPABASE_URL = process.env.SUPABASE_URL;
const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

function reply(res, status, body) {
  res.status(status).setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(body));
}

async function rawBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(Buffer.from(chunk));
  return Buffer.concat(chunks);
}

function get(source, paths) {
  for (const path of paths) {
    let value = source;
    for (const part of path.split('.')) value = value?.[part];
    if (value !== undefined && value !== null && value !== '') return value;
  }
  return '';
}

function normalizeEvent(value = '') {
  return String(value).trim().toLowerCase().replace(/[\s.-]+/g, '_');
}

function verifyRequest(req, body) {
  const signature = req.headers['x-kiwify-digital-signature'];
  const timestamp = req.headers['x-kiwify-timestamp'];
  const publicKey = process.env.KIWIFY_WEBHOOK_PUBLIC_KEY;
  if (signature && timestamp && publicKey) {
    if (Math.abs(Date.now() - Number(timestamp)) > 300000) return false;
    const path = new URL(req.url, 'https://local.invalid').pathname || '/api/kiwify-webhook';
    const message = `${path}:POST:${body.toString('utf8')}:${timestamp}`;
    const digest = crypto.createHash('sha256').update(message, 'utf8').digest();
    const decoded = Buffer.from(String(signature).replace(/-/g, '+').replace(/_/g, '/'), 'base64');
    return crypto.verify(null, digest, publicKey.replace(/\\n/g, '\n'), decoded);
  }
  const supplied = new URL(req.url, 'https://local.invalid').searchParams.get('token') || req.headers['x-webhook-secret'];
  const expected = process.env.KIWIFY_WEBHOOK_SECRET;
  if (!expected || !supplied) return false;
  const suppliedBytes = Buffer.from(String(supplied)), expectedBytes = Buffer.from(String(expected));
  return suppliedBytes.length === expectedBytes.length && crypto.timingSafeEqual(suppliedBytes, expectedBytes);
}

async function supabase(path, { method = 'GET', body, prefer } = {}) {
  const response = await fetch(SUPABASE_URL.replace(/\/$/, '') + path, {
    method,
    headers: { apikey: SERVICE_KEY, Authorization: `Bearer ${SERVICE_KEY}`, 'Content-Type': 'application/json', ...(prefer ? { Prefer: prefer } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body)
  });
  const text = await response.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch { data = { message: text }; }
  if (!response.ok) throw new Error(data.message || data.error || 'Falha ao atualizar a assinatura.');
  return data;
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return reply(res, 405, { error: 'Método não permitido.' });
  if (!SUPABASE_URL || !SERVICE_KEY) return reply(res, 503, { error: 'Servidor não configurado.' });
  try {
    const raw = await rawBody(req);
    if (!verifyRequest(req, raw)) return reply(res, 401, { error: 'Assinatura do webhook inválida.' });
    const payload = JSON.parse(raw.toString('utf8'));
    const eventType = normalizeEvent(get(payload, ['webhook_event_type', 'event', 'type', 'order_status', 'data.event']));
    const email = String(get(payload, ['customer.email', 'Customer.email', 'buyer.email', 'order.customer.email', 'data.customer.email', 'data.buyer.email'])).trim().toLowerCase();
    const subscriptionRef = String(get(payload, ['subscription_id', 'subscription.id', 'data.subscription_id', 'data.subscription.id']));
    const orderRef = String(get(payload, ['order_id', 'order.id', 'sale_id', 'data.order_id', 'data.id']));
    if (!eventType || !email) return reply(res, 202, { ignored: true, reason: 'Evento ou e-mail não identificado.' });

    const profiles = await supabase(`/rest/v1/profiles?select=id&email=eq.${encodeURIComponent(email)}`);
    if (!profiles.length) return reply(res, 202, { ignored: true, reason: 'Cliente ainda não cadastrado no sistema.' });
    const farms = await supabase(`/rest/v1/farms?select=id&owner_id=eq.${profiles[0].id}`);
    if (!farms.length) return reply(res, 202, { ignored: true, reason: 'Fazenda não localizada.' });
    const farmId = farms[0].id;
    const eventId = crypto.createHash('sha256').update(`${eventType}|${subscriptionRef}|${orderRef}|${raw.toString('utf8')}`).digest('hex');
    const inserted = await supabase('/rest/v1/subscription_events?on_conflict=provider,provider_event_id', {
      method: 'POST', prefer: 'resolution=ignore-duplicates,return=representation',
      body: { farm_id: farmId, provider: 'Kiwify', provider_event_id: eventId, event_type: eventType, payload, processed_at: new Date().toISOString() }
    });
    if (!inserted.length) return reply(res, 200, { ok: true, duplicate: true });

    const statusMap = {
      compra_aprovada: 'active', subscription_renewed: 'active', assinatura_renovada: 'active',
      subscription_late: 'late', assinatura_atrasada: 'late',
      subscription_canceled: 'canceled', assinatura_cancelada: 'canceled',
      compra_reembolsada: 'refunded', refund: 'refunded',
      chargeback: 'chargeback'
    };
    const status = statusMap[eventType];
    if (status) {
      const periodStart = get(payload, ['subscription.current_period_start', 'data.current_period_start', 'approved_date']);
      const periodEnd = get(payload, ['subscription.current_period_end', 'subscription.next_payment_date', 'data.current_period_end', 'next_payment_date']);
      await supabase('/rest/v1/subscriptions?on_conflict=farm_id', {
        method: 'POST', prefer: 'resolution=merge-duplicates,return=minimal',
        body: { farm_id: farmId, plan: 'Mensal — R$ 97,00', amount: 97, billing_cycle: 'monthly', provider: 'Kiwify', provider_reference: orderRef || null, provider_subscription_id: subscriptionRef || null, checkout_url: 'https://pay.kiwify.com.br/kmJTFbU', status, current_period_start: periodStart || null, current_period_end: periodEnd || null }
      });
    }
    return reply(res, 200, { ok: true, event: eventType });
  } catch (error) {
    return reply(res, 400, { error: error.message });
  }
}
