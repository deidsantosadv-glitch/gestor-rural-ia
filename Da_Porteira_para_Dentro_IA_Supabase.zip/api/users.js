const SUPABASE_URL = process.env.SUPABASE_URL;
const ANON_KEY = process.env.SUPABASE_ANON_KEY;
const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

function reply(res, status, body) {
  res.status(status).setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(body));
}

async function supabase(path, { method = 'GET', token = SERVICE_KEY, body, prefer } = {}) {
  const response = await fetch(SUPABASE_URL.replace(/\/$/, '') + path, {
    method,
    headers: {
      apikey: token === SERVICE_KEY ? SERVICE_KEY : ANON_KEY,
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
      ...(prefer ? { Prefer: prefer } : {})
    },
    body: body === undefined ? undefined : JSON.stringify(body)
  });
  const text = await response.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch { data = { message: text }; }
  if (!response.ok) throw new Error(data.message || data.msg || data.error_description || data.error || 'Falha no Supabase.');
  return data;
}

export default async function handler(req, res) {
  if (!['POST', 'PATCH'].includes(req.method)) return reply(res, 405, { error: 'Método não permitido.' });
  if (!SUPABASE_URL || !ANON_KEY || !SERVICE_KEY) return reply(res, 503, { error: 'Integração Supabase não configurada no servidor.' });
  try {
    const callerToken = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    if (!callerToken) return reply(res, 401, { error: 'Sessão não informada.' });
    const caller = await supabase('/auth/v1/user', { token: callerToken });
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : (req.body || {});
    const { id, farmId, name, email, phone = '', role, status = 'Ativo' } = body;
    if (!farmId || !name || !email || !role) return reply(res, 400, { error: 'Preencha fazenda, nome, e-mail e perfil.' });

    const memberships = await supabase(`/rest/v1/farm_members?select=role,status&farm_id=eq.${farmId}&user_id=eq.${caller.id}`);
    const farms = await supabase(`/rest/v1/farms?select=owner_id&id=eq.${farmId}`);
    const callerRole = farms[0]?.owner_id === caller.id ? 'Proprietário' : memberships[0]?.role;
    if (!['Proprietário', 'Gestor'].includes(callerRole) || memberships[0]?.status === 'Inativo') return reply(res, 403, { error: 'Seu perfil não pode administrar usuários.' });
    if (role === 'Proprietário' && callerRole !== 'Proprietário') return reply(res, 403, { error: 'Somente o proprietário pode conceder este perfil.' });

    let userId = id;
    if (req.method === 'POST') {
      const redirect = process.env.SITE_URL ? `?redirect_to=${encodeURIComponent(process.env.SITE_URL)}` : '';
      const invited = await supabase(`/auth/v1/invite${redirect}`, { method: 'POST', body: { email: email.toLowerCase(), data: { name, phone } } });
      userId = invited.id || invited.user?.id;
      if (!userId) throw new Error('O Supabase não retornou o usuário convidado.');
      await supabase('/rest/v1/farm_members?on_conflict=farm_id,user_id', {
        method: 'POST', prefer: 'resolution=merge-duplicates,return=minimal',
        body: { farm_id: farmId, user_id: userId, role, status }
      });
    } else {
      if (!userId) return reply(res, 400, { error: 'Usuário não informado.' });
      await supabase(`/auth/v1/admin/users/${userId}`, { method: 'PUT', body: { email: email.toLowerCase(), user_metadata: { name, phone } } });
      await supabase(`/rest/v1/profiles?id=eq.${userId}`, { method: 'PATCH', body: { name, email: email.toLowerCase(), phone } });
      await supabase(`/rest/v1/farm_members?farm_id=eq.${farmId}&user_id=eq.${userId}`, { method: 'PATCH', body: { role, status } });
    }
    return reply(res, 200, { ok: true, userId });
  } catch (error) {
    return reply(res, 400, { error: error.message });
  }
}
