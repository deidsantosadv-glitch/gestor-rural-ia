-- DA PORTEIRA PARA DENTRO IA
-- Banco PostgreSQL/Supabase pronto para autenticação, múltiplas fazendas e isolamento de dados.
-- Execute este arquivo uma única vez no SQL Editor do projeto Supabase.

create extension if not exists pgcrypto;

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null,
  email text not null,
  phone text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.handle_new_auth_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,name,email,phone)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'name',split_part(coalesce(new.email,''),'@',1),'Usuário'),
    coalesce(new.email,''),
    new.raw_user_meta_data->>'phone'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_auth_user();

create table if not exists public.farms (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  owner_id uuid not null references public.profiles(id),
  total_area numeric(14,2) not null default 0,
  coffee_area numeric(14,2) not null default 0,
  latitude numeric(10,7),
  longitude numeric(10,7),
  trial_started_at timestamptz not null default now(),
  trial_ends_at timestamptz not null default (now() + interval '30 days'),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.farm_members (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null check (role in ('Proprietário','Gestor','Encarregado','Funcionário','Consultor','Financeiro')),
  status text not null default 'Ativo' check (status in ('Ativo','Inativo','Pendente')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(farm_id,user_id)
);

create table if not exists public.farm_invitations (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  email text not null,
  role text not null,
  token_hash text not null unique,
  status text not null default 'Pendente',
  expires_at timestamptz not null default (now() + interval '72 hours'),
  invited_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null unique references public.farms(id) on delete cascade,
  plan text not null default 'Teste gratuito — 30 dias',
  amount numeric(14,2) not null default 0,
  billing_cycle text,
  provider text not null default 'Kiwify',
  provider_reference text,
  provider_customer_id text,
  provider_subscription_id text,
  checkout_url text not null default 'https://pay.kiwify.com.br/kmJTFbU',
  status text not null default 'trialing',
  current_period_start timestamptz,
  current_period_end timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Mantém instalações anteriores compatíveis com a recorrência mensal da Kiwify.
alter table public.subscriptions alter column provider set default 'Kiwify';
alter table public.subscriptions add column if not exists provider_customer_id text;
alter table public.subscriptions add column if not exists provider_subscription_id text;
alter table public.subscriptions add column if not exists checkout_url text not null default 'https://pay.kiwify.com.br/kmJTFbU';

create unique index if not exists idx_subscriptions_provider_subscription
on public.subscriptions(provider,provider_subscription_id)
where provider_subscription_id is not null;

create table if not exists public.subscription_events (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  subscription_id uuid references public.subscriptions(id) on delete set null,
  provider text not null default 'Kiwify',
  provider_event_id text not null,
  event_type text not null,
  payload jsonb not null default '{}'::jsonb,
  processed_at timestamptz,
  processing_error text,
  created_at timestamptz not null default now(),
  unique(provider,provider_event_id)
);

create table if not exists public.budget_cycles (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  season text not null,
  coffee_area numeric(14,2) not null,
  productivity_sacks_ha numeric(14,2) not null,
  expected_sacks numeric(14,2) not null,
  target_cost_per_sack numeric(14,2) not null,
  expected_sale_price_per_sack numeric(14,2) not null,
  planned_total numeric(14,2) not null,
  status text not null default 'Ativo',
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(farm_id,season)
);

create table if not exists public.budget_items (
  id uuid primary key default gen_random_uuid(),
  budget_cycle_id uuid not null references public.budget_cycles(id) on delete cascade,
  farm_id uuid not null references public.farms(id) on delete cascade,
  category_key text not null,
  category_name text not null,
  initial_percentage numeric(7,2) not null default 0,
  planned_amount numeric(14,2) not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(budget_cycle_id,category_key)
);

create table if not exists public.financial_entries (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  entry_type text not null check (entry_type in ('Entrada','Saída')),
  entry_date date not null,
  description text not null,
  amount numeric(14,2) not null check (amount >= 0),
  budget_key text,
  category text,
  cost_center text,
  document_number text,
  bank_account text,
  reconciled boolean not null default false,
  source text not null default 'manual',
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  direction text not null check (direction in ('Entrada','Saída')),
  issue_date date,
  number text,
  access_key varchar(44),
  issuer_recipient text,
  amount numeric(14,2) default 0,
  taxes numeric(14,2) default 0,
  item_count integer default 0,
  xml_path text,
  status text not null default 'Registrada',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(farm_id,access_key)
);

create table if not exists public.bank_transactions (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  transaction_date date not null,
  description text not null,
  amount numeric(14,2) not null,
  external_id text,
  statement_file text,
  reconciled boolean not null default false,
  financial_entry_id uuid references public.financial_entries(id) on delete set null,
  created_at timestamptz not null default now(),
  unique(farm_id,external_id)
);

create table if not exists public.plots (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  name text not null,
  crop text,
  variety text,
  area numeric(14,2) default 0,
  planting_date date,
  status text default 'Ativo',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.operations (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  plot_id uuid references public.plots(id) on delete set null,
  title text not null,
  assigned_to uuid references public.profiles(id),
  due_date date,
  priority text,
  status text not null default 'Planejado',
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.inventory_items (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  name text not null,
  category text,
  quantity numeric(14,3) not null default 0,
  minimum_quantity numeric(14,3) not null default 0,
  unit text,
  unit_cost numeric(14,2) default 0,
  expires_at date,
  status text default 'Ativo',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.machines (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  name text not null,
  model text,
  hour_meter numeric(14,2) default 0,
  next_maintenance date,
  responsible_id uuid references public.profiles(id),
  status text default 'Ativo',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.water_measurements (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  measured_at date not null,
  point_name text not null,
  water_depth_m numeric(10,2) not null,
  method text,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.weather_snapshots (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  captured_at timestamptz not null default now(),
  temperature numeric(8,2),
  humidity numeric(8,2),
  rainfall_mm numeric(10,2),
  wind_kmh numeric(10,2),
  weather_code integer,
  alerts jsonb not null default '[]'::jsonb
);

create table if not exists public.lab_analyses (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  plot_id uuid references public.plots(id) on delete set null,
  analysis_type text not null check (analysis_type in ('Solo','Foliar')),
  collected_at date,
  crop text,
  laboratory text,
  technician text,
  file_path text,
  results jsonb not null default '{}'::jsonb,
  preliminary_recommendation text,
  status text not null default 'Aguardando validação',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.esocial_events (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  event_code text not null,
  worker_name text not null,
  worker_cpf text,
  registration text,
  event_date date,
  receipt text,
  status text not null default 'Pendente',
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.training_courses (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  title text not null,
  track text,
  youtube_url text,
  workload text,
  responsible_id uuid references public.profiles(id),
  due_date date,
  status text default 'Disponível',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.training_progress (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  course_id uuid not null references public.training_courses(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  progress numeric(5,2) not null default 0,
  completed_at timestamptz,
  unique(course_id,user_id)
);

create table if not exists public.farm_records (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  module text not null,
  title text not null,
  status text,
  responsible_id uuid references public.profiles(id),
  due_date date,
  data jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
  id bigint generated always as identity primary key,
  farm_id uuid references public.farms(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete set null,
  action text not null,
  entity text,
  entity_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- Estado consolidado da aplicação. Mantém todos os módulos sincronizados entre
-- computador e celular enquanto as tabelas especializadas seguem disponíveis
-- para relatórios, integrações e evolução gradual.
create table if not exists public.farm_app_states (
  farm_id uuid primary key references public.farms(id) on delete cascade,
  state jsonb not null default '{}'::jsonb,
  version bigint not null default 1,
  updated_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.is_farm_member(target_farm uuid)
returns boolean language sql stable security definer set search_path=public as $$
  select exists (
    select 1 from public.farm_members fm
    where fm.farm_id=target_farm and fm.user_id=auth.uid() and fm.status='Ativo'
  );
$$;

create or replace function public.shares_farm(target_user uuid)
returns boolean language sql stable security definer set search_path=public as $$
  select exists (
    select 1
    from public.farm_members mine
    join public.farm_members other_member on other_member.farm_id=mine.farm_id
    where mine.user_id=auth.uid() and mine.status='Ativo'
      and other_member.user_id=target_user and other_member.status='Ativo'
  );
$$;

create or replace function public.has_farm_role(target_farm uuid, allowed_roles text[])
returns boolean language sql stable security definer set search_path=public as $$
  select exists (
    select 1 from public.farm_members fm
    where fm.farm_id=target_farm and fm.user_id=auth.uid()
      and fm.status='Ativo' and fm.role=any(allowed_roles)
  ) or exists (
    select 1 from public.farms f
    where f.id=target_farm and f.owner_id=auth.uid()
      and 'Proprietário'=any(allowed_roles)
  );
$$;

create or replace function public.create_farm_trial()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.subscriptions(
    farm_id,plan,amount,billing_cycle,provider,checkout_url,status,
    current_period_start,current_period_end
  ) values (
    new.id,'Teste gratuito — 30 dias',0,'trial','Kiwify',
    'https://pay.kiwify.com.br/kmJTFbU','trialing',new.trial_started_at,new.trial_ends_at
  ) on conflict (farm_id) do nothing;
  return new;
end;
$$;

drop trigger if exists create_farm_trial on public.farms;
create trigger create_farm_trial
after insert on public.farms
for each row execute function public.create_farm_trial();

alter table public.profiles enable row level security;
create policy "profile_self_read" on public.profiles for select using (id=auth.uid());
create policy "profile_same_farm_read" on public.profiles for select using (public.shares_farm(id));
create policy "profile_self_update" on public.profiles for update using (id=auth.uid()) with check (id=auth.uid());

alter table public.farms enable row level security;
create policy "farms_members_read" on public.farms for select using (public.is_farm_member(id) or owner_id=auth.uid());
create policy "farms_owner_insert" on public.farms for insert with check (owner_id=auth.uid());
create policy "farms_manager_update" on public.farms for update using (
  owner_id=auth.uid() or exists(select 1 from public.farm_members fm where fm.farm_id=id and fm.user_id=auth.uid() and fm.role in ('Proprietário','Gestor') and fm.status='Ativo')
);

alter table public.farm_members enable row level security;
create policy "members_same_farm_read" on public.farm_members for select using (public.is_farm_member(farm_id));
create policy "members_owner_manage" on public.farm_members for all using (
  exists(select 1 from public.farms f where f.id=farm_id and f.owner_id=auth.uid())
) with check (
  exists(select 1 from public.farms f where f.id=farm_id and f.owner_id=auth.uid())
);

do $$
declare table_name text;
begin
  foreach table_name in array array[
    'farm_invitations','subscriptions','subscription_events','budget_cycles','budget_items','financial_entries',
    'invoices','bank_transactions','plots','operations','inventory_items','machines',
    'water_measurements','weather_snapshots','lab_analyses','esocial_events',
    'training_courses','training_progress','farm_records','audit_logs'
  ] loop
    execute format('alter table public.%I enable row level security',table_name);
    execute format('create policy %I on public.%I for select using (public.is_farm_member(farm_id))','farm_read_'||table_name,table_name);
    execute format('create policy %I on public.%I for insert with check (public.is_farm_member(farm_id))','farm_insert_'||table_name,table_name);
    execute format('create policy %I on public.%I for update using (public.is_farm_member(farm_id)) with check (public.is_farm_member(farm_id))','farm_update_'||table_name,table_name);
    execute format('create policy %I on public.%I for delete using (public.is_farm_member(farm_id))','farm_delete_'||table_name,table_name);
  end loop;
end $$;

-- Endurecimento de tabelas sensíveis. Assinaturas e eventos da Kiwify só são
-- escritos pelo servidor com service_role; usuários autenticados apenas leem.
drop policy if exists farm_insert_subscriptions on public.subscriptions;
drop policy if exists farm_update_subscriptions on public.subscriptions;
drop policy if exists farm_delete_subscriptions on public.subscriptions;
drop policy if exists farm_insert_subscription_events on public.subscription_events;
drop policy if exists farm_update_subscription_events on public.subscription_events;
drop policy if exists farm_delete_subscription_events on public.subscription_events;
drop policy if exists farm_update_audit_logs on public.audit_logs;
drop policy if exists farm_delete_audit_logs on public.audit_logs;

alter table public.farm_app_states enable row level security;
drop policy if exists farm_state_read on public.farm_app_states;
drop policy if exists farm_state_insert on public.farm_app_states;
drop policy if exists farm_state_update on public.farm_app_states;
create policy farm_state_read on public.farm_app_states for select
using (public.is_farm_member(farm_id));
create policy farm_state_insert on public.farm_app_states for insert
with check (public.has_farm_role(farm_id,array['Proprietário','Gestor','Encarregado','Financeiro']));
create policy farm_state_update on public.farm_app_states for update
using (public.has_farm_role(farm_id,array['Proprietário','Gestor','Encarregado','Financeiro']))
with check (public.has_farm_role(farm_id,array['Proprietário','Gestor','Encarregado','Financeiro']));

-- Bucket privado para laudos, XML, extratos, documentos e imagens da fazenda.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values (
  'farm-files','farm-files',false,52428800,
  array['application/pdf','application/xml','text/xml','text/csv','application/octet-stream','image/jpeg','image/png','image/webp']
)
on conflict (id) do update set
  public=false,
  file_size_limit=excluded.file_size_limit,
  allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists farm_files_read on storage.objects;
drop policy if exists farm_files_insert on storage.objects;
drop policy if exists farm_files_update on storage.objects;
drop policy if exists farm_files_delete on storage.objects;
create policy farm_files_read on storage.objects for select to authenticated
using (bucket_id='farm-files' and public.is_farm_member(((storage.foldername(name))[1])::uuid));
create policy farm_files_insert on storage.objects for insert to authenticated
with check (bucket_id='farm-files' and public.has_farm_role(((storage.foldername(name))[1])::uuid,array['Proprietário','Gestor','Encarregado','Financeiro']));
create policy farm_files_update on storage.objects for update to authenticated
using (bucket_id='farm-files' and public.has_farm_role(((storage.foldername(name))[1])::uuid,array['Proprietário','Gestor','Encarregado','Financeiro']));
create policy farm_files_delete on storage.objects for delete to authenticated
using (bucket_id='farm-files' and public.has_farm_role(((storage.foldername(name))[1])::uuid,array['Proprietário','Gestor']));

create index if not exists idx_members_user on public.farm_members(user_id);
create index if not exists idx_subscription_events_farm_date on public.subscription_events(farm_id,created_at desc);
create index if not exists idx_financial_farm_date on public.financial_entries(farm_id,entry_date);
create index if not exists idx_financial_budget on public.financial_entries(farm_id,budget_key);
create index if not exists idx_budget_items_cycle on public.budget_items(budget_cycle_id);
create index if not exists idx_operations_farm_status on public.operations(farm_id,status);
create index if not exists idx_inventory_farm on public.inventory_items(farm_id);
create index if not exists idx_invoices_farm_date on public.invoices(farm_id,issue_date);
create index if not exists idx_audit_farm_date on public.audit_logs(farm_id,created_at desc);
create index if not exists idx_subscription_events_reference on public.subscription_events(provider,event_type,created_at desc);

do $$
declare table_name text;
begin
  foreach table_name in array array[
    'profiles','farms','farm_members','subscriptions','budget_cycles','budget_items',
    'financial_entries','invoices','plots','operations','inventory_items','machines',
    'lab_analyses','esocial_events','training_courses','farm_records'
  ] loop
    execute format('drop trigger if exists set_updated_at on public.%I',table_name);
    execute format('create trigger set_updated_at before update on public.%I for each row execute function public.set_updated_at()',table_name);
  end loop;
end $$;

drop trigger if exists set_updated_at on public.farm_app_states;
create trigger set_updated_at before update on public.farm_app_states
for each row execute function public.set_updated_at();

-- O cadastro de senha deve ser feito pelo Supabase Auth. Nunca armazene senha em texto aberto.
