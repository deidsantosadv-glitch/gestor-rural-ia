// Configuração pública do Supabase.
// Preencha antes de publicar. A anonKey é pública; nunca use a service_role aqui.
window.DPD_CONFIG = {
  supabase: {
    url: 'https://iflwrzicosglewxyiufs.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlmbHdyemljb3NnbGV3eHlpdWZzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODYwNTIzMjQsImV4cCI6MjEwMTYyODMyNH0.k9rRFJowy0g-0oCz-xtMiguWpU6lzMiwm8dyjhjcmuE'
  }
};
